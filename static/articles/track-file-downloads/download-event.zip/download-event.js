/**
 * Track File Downloads
 *
 * @author Thijs Busser
 * @version 1.0
 * @tutorial http://tbusser.net/articles/track-file-downloads
 *
 * This script attaches a click handler to all elements with the attribute
 * 'data-ga'. It will attempt to send an event to Google Analytics when the
 * user clicked on the element. The data to send with the event should be
 * in the value of the data-ga attribute, the value should be in JSON format
 */
(function() {
	'use strict';

	// Get all anchor elements that have information for a Google Analytics event in the data-ga atttibute
	var links = document.querySelectorAll('[data-ga]');
	// Loop over all the elements we've found
	for (var index=0,ubound=links.length; index<ubound; index++) {
		// Attach an event handler on the click event
		links[index].addEventListener('click', handleClickEvent.bind(this));
	}

	function handleClickEvent(event) {
		// Get the content from the data-ga attribute from the element that send the click event
		var data = event.currentTarget.getAttribute('data-ga');
		// We'll be parsing the content of the attribute as JSON, in order to be able
		// to do this we need to make sure all single quotes in the string are double quotes.
		// This regular expression replaces all instances of a single quote
		data = data.replace(/\'/g, '"');
		// Now we can parse the string to an object. If you're not sure this attribute will
		// always contain a string which can be parsed as JSON you should add a try...catch
		// around this so your code won't crash
		try {
			data = JSON.parse(data);
			// Set a timeout of 400ms, after the time out has lapsed we will send the event
			// to Google
			setTimeout(function() {
				// Send the event to Google Analytics. We use the properties from the object we've parsed
				// from the attribute. Be sure to pass the value parameter as a number
				ga.send('send', 'event', data.category, data.action, data.label, parseInt(data.value, 10));
			}, 400);
		} catch (exception) {
			console.log('Unable to parse the string <' + data + '> as JSON');
		}
	}
})();