/**
 * Load Disqus comments on demand
 *
 * @author Thijs Busser
 * @version 1.0
 * @tutorial http://tbusser.net/articles/disqus-on-demand
 *
 * This script initializes the page for the visitor to download load the Disqus comments on demand. To do
 * this we remove the message alerting the visitor of the JS dependency and we add a button which allows
 * the user to load in the comments from Disqus.
 *
 * This script also polls the anchor element with the href ending on #disqus_thread to get the comment
 * count for the discussion so this can be shown in the button.
 */
(function() {
	'use strict';

	var disqus_shortname = 'example', // required: replace example with your forum shortname
		interval = 208,
		link = null,
		maxTries = 8,
		pollTries = 0;

	/**
	 * Add the text from the anchor in the button to show the current comment count.
	 */
	function addCommentTextToButton() {
		// Get the text from the anchor, make sure it is all lower case
		var text = link.innerHTML.toLowerCase();
		// If there is a single comment we need to use 'is' in the sentence instead of 'are'
		var verb = (parseInt(text, 10) === 1) ? 'is ' : 'are ';
		// Add the text to the button to show how many comments there are, use the verb we determined
		// and the comment count we got from the anchor
		var button = document.getElementById('disqus_thread');
		button.appendChild(document.createTextNode(' Right now there ' + verb + link.innerHTML.toLowerCase() + '.'));
	}

	/**
	 * This method will handle the click on the button to load the comments. It will remove the
	 * button and execute the original Disqus script for loading the comments.
	 */
	function button_clickHandler(event) {
		// We need to get the button element, we could also use the target property of the event
		// but this will do just as well
		var button = document.getElementById('disqus_thread');
		// Now we will have to recreate the div element we removed from the HTML. We will place
		// it into the DOM like we did when we created the button
		var disqusContainer = document.createElement('div');
		button.parentNode.insertBefore(disqusContainer, button);
		button.parentNode.removeChild(button);

		// The div element will need to have the disqus_thread id as this is required for Disqus,
		// it is the way their code identifies the element in which the comments can be displayed
		disqusContainer.id = 'disqus_thread';

		// Now we can execute the original Disqus code
		var dsq = document.createElement('script');
		dsq.type = 'text/javascript';
		dsq.async = true;
		dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
		(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
	}

	/**
	 * This method will initialize the module. It will replace the JavaScript dependency message
	 * with a button which will allow the visitor to load the comments.
	 */
	function init() {
		// Try to get the element we used to display the message about the JavaScript dependency
		var placeholder = document.getElementById('disqus_thread');
		// If we didn't get the placeholder element we will stop setting up the button to load
		// the comments
		if (placeholder == null) {
			return;
		}

		// The placeholder was found, now we can create the button which will allow the visitor to
		// load the comments
		var button = document.createElement('button');
		button.appendChild(document.createTextNode('Click here to load the comments.'));
		button.addEventListener('click', button_clickHandler.bind(this));

		// We will insert the button before the placeholder and once the button has been placed in
		// the DOM we will remove the placeholder
		placeholder.parentNode.insertBefore(button, placeholder);
		placeholder.parentNode.removeChild(placeholder);

		// The placeholder used to have the id which can be reference by an anchor element, to make
		// sure we don't break this functionality we will apply the id to our newly created button
		button.id = 'disqus_thread';

		// Try to get an anchor element with a href to #disqus_thread, this is where
		// the text with the comment count will be placed in
		link = document.querySelector('[href$="#disqus_thread"]');
		// Check if we've found an element with the requested href
		if (link != null) {
			// Start polling the text inside the anchor element
			pollCommentText();
		}
	}

	/**
	 * This method will poll the text inside the anchor element until it contains text. It
	 * will do so for maximal 8 times before giving up. The time between each attempt will
	 * be 20% longer than the last. With an initial interval of 208ms the math works out
	 * to:
	 *  1: 250ms
	 *  2: 300ms
	 *  3: 360ms
	 *  4: 432ms
	 *  5: 518ms
	 *  6: 622ms
	 *  7: 746ms
	 *  8: 895ms
	 * The method will stop checking for the comment count after 4.1 seconds.
	 */
	function pollCommentText() {
		// Check if the anchor element still is empty
		if (link.innerHTML === '') {
			// Increase the poll counter
			pollTries++;
			// Check if we haven't exceeded the max number of tries
			if (pollTries <= maxTries) {
				// Wait an additional 20% longer between each attempt
				interval *= 1.2;
				// We still have a try left, check if the anchor has text in a while
				setTimeout(pollCommentText, interval);
			}
		} else {
			// The anchor contains text, add it to the button
			addCommentTextToButton();
		}
	}

	// Setup the module
	init();
})();